# Flower_Disease > 2024-11-20 10:07pm
https://universe.roboflow.com/florys/flower_disease

Provided by a Roboflow user
License: Public Domain

